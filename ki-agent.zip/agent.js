const memory = new Memory();
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let agent = { x: canvas.width / 2, y: canvas.height / 2, size: 20, color: 'white' };

function draw() {
    ctx.fillStyle = 'rgba(0,0,0,0.2)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.beginPath();
    ctx.arc(agent.x, agent.y, agent.size, 0, Math.PI * 2);
    ctx.fillStyle = agent.color;
    ctx.fill();
}

canvas.addEventListener('mousemove', (e) => {
    agent.x += (e.clientX - agent.x) * 0.05;
    agent.y += (e.clientY - agent.y) * 0.05;
    memory.remember({ x: agent.x, y: agent.y });
});

function loop() {
    draw();
    requestAnimationFrame(loop);
}
loop();
