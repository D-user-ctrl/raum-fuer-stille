class Memory {
    constructor(maxSize = 1000) {
        this.maxSize = maxSize;
        this.data = [];
    }
    remember(observation) {
        this.data.push({ time: Date.now(), ...observation });
        if (this.data.length > this.maxSize) this.data.shift();
    }
    recallLatest(n = 10) {
        return this.data.slice(-n);
    }
}
